
--LIDER
INSERT INTO Types	
		(Type, Kind)
VALUES	('LEADER_HICCUP_BD', 'KIND_LEADER');	

INSERT INTO Leaders	
		(LeaderType, Name, InheritFrom, SceneLayers)
VALUES	('LEADER_HICCUP_BD', 'HICCUP', 'LEADER_DEFAULT',	4);	

INSERT INTO LeaderQuotes	
		(LeaderType, Quote)
VALUES	('LEADER_HICCUP_BD', 'A dragons trust is earned, not given');	

INSERT INTO LoadingInfo	
		(LeaderType, BackgroundImage, ForegroundImage, PlayDawnOfManAudio)
VALUES	('LEADER_HICCUP_BD', 'LEADER_LEADER_CUSTOM_BACKGROUND',	'LEADER_LEADER_CUSTOM_NEUTRAL', 0);	

INSERT INTO DiplomacyInfo			
		(Type, BackgroundImage)
VALUES	('LEADER_HICCUP_BD', 'ART_LEADER_LEADER_CUSTOM.dds');

INSERT INTO HistoricalAgendas	
		(LeaderType, AgendaType)
VALUES	('LEADER_HICCUP_BD',	'AGENDA_ALLY_OF_ENKIDU'); -- Le gustan las civilizaciones que est�n dispuestas a formar alianzas duraderas. No le gustan los que denuncian o atacan a sus amigos y aliados.

INSERT INTO AgendaPreferredLeaders	
		(LeaderType, AgendaType)
VALUES	('LEADER_HICCUP_BD',	'AGENDA_ENVIRONMENTALIST');	 --Intenta encontrar todas las maravillas naturales. Le gustan las civilizaciones que no talan los Bosques ni las Selvas tropicales y aquellas que fundan Parques nacionales.

INSERT INTO Types	
		(Type, Kind)
VALUES	('TRAIT_LEADER_HICCUP_BD_LTRAIT', 'KIND_TRAIT');	
			
INSERT INTO Traits				
		(TraitType, Name, Description)
VALUES	('TRAIT_LEADER_HICCUP_BD_LTRAIT', 'THE DRAGON CONQUEROR',	'This archipelago, located in a fantastic and legendary realm, is a place of astounding natural beauty and geographical diversity. From towering snowy mountains to lush forests and vast oceans, Berk offers a variety of landscapes that have shaped the life and culture of its inhabitants. In ancient times, these islands were covered with dense forests and rugged cliffs, providing shelter for both dragons and the Vikings who inhabited them. The richness of its natural environment was crucial for the survival and prosperity of its early tribes.');	
		
INSERT INTO TraitModifiers			
		(TraitType,	ModifierId)
VALUES	('TRAIT_LEADER_HICCUP_BD_LTRAIT', 'TRAIT_BONUS_AGAINST_BARBS');

INSERT INTO LeaderTraits	
		(LeaderType, TraitType)
VALUES	('LEADER_HICCUP_BD', 'TRAIT_LEADER_HICCUP_BD_LTRAIT');	

--CIVILIZACION
INSERT INTO Types	
		(Type, Kind)
VALUES	('CIVILIZATION_CETD_BD', 'KIND_CIVILIZATION');

INSERT INTO Civilizations	
		(CivilizationType, Name, Description, Adjective, StartingCivilizationLevelType,	RandomCityNameDepth)
VALUES	('CIVILIZATION_CETD_BD', 'How To Train a Dragon', 'Welcome!', 'LOC_CIVILIZATION_CETD_BD_ADJECTIVE',	'CIVILIZATION_LEVEL_FULL_CIV', 30);

INSERT INTO CivilizationInfo	
		(CivilizationType, Header, Caption,	SortIndex)	
VALUES	('CIVILIZATION_CETD_BD', 'LOC_CIVINFO_LOCATION', 'LOC_CIVINFO_CETD_BD_LOCATION', 10),	
		('CIVILIZATION_CETD_BD', 'LOC_CIVINFO_SIZE', 'LOC_CIVINFO_CETD_BD_SIZE', 20),	
		('CIVILIZATION_CETD_BD', 'LOC_CIVINFO_POPULATION', 'LOC_CIVINFO_CETD_BD_POPULATION', 30),	
		('CIVILIZATION_CETD_BD', 'LOC_CIVINFO_CAPITAL', 'LOC_CIVINFO_CETD_BD_CAPITAL', 40);

INSERT INTO CivilizationLeaders	
		(CivilizationType, LeaderType,	CapitalName)
VALUES	('CIVILIZATION_CETD_BD','LEADER_HICCUP_BD', 'MEMA');

INSERT INTO CityNames	
		(CivilizationType,			CityName)	
VALUES	('CIVILIZATION_CETD_BD',	'Vanaheim'),	
		('CIVILIZATION_CETD_BD',	'Hidden World'),	
		('CIVILIZATION_CETD_BD',	'Berserker'),	
		('CIVILIZATION_CETD_BD',	'City of Dragons'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_6'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_7'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_8'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_9'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_10'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_11'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_12'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_13'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_14'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_15'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_16'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_17'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_18'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_19'),	
		('CIVILIZATION_CETD_BD',	'LOC_CITY_NAME_20');

INSERT INTO CivilizationCitizenNames	
		(CivilizationType, CitizenName,	Female,	Modern)
VALUES	('CIVILIZATION_CETD_BD', 'LOC_CITIZEN_CETD_BD_MALE_1',				0,			0),
		('CIVILIZATION_CETD_BD', 'LOC_CITIZEN_CETD_BD_MALE_2',				0,			0),
		('CIVILIZATION_CETD_BD', 'LOC_CITIZEN_CETD_BD_MALE_3',				0,			0),
		('CIVILIZATION_CETD_BD', 'LOC_CITIZEN_CETD_BD_MALE_4',				0,			0),
		('CIVILIZATION_CETD_BD', 'LOC_CITIZEN_CETD_BD_MALE_5',				0,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_FEMALE_1',			1,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_FEMALE_2',			1,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_FEMALE_3',			1,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_FEMALE_4',			1,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_FEMALE_5',			1,			0),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_MALE_1',		0,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_MALE_2',		0,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_MALE_3',		0,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_MALE_4',		0,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_MALE_5',		0,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_1',		1,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_2',		1,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_3',		1,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_4',		1,			1),
		('CIVILIZATION_CETD_BD',	'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_5',		1,			1),

--COLORES
INSERT INTO PlayerColors	
		(Type, Usage, PrimaryColor, SecondaryColor,	TextColor)
VALUES	('LEADER_HICCUP_BD', 'Unique', 'COLOR_PLAYER_CETD_BD_PRIMARY', 'COLOR_PLAYER_CETD_BD_SECONDARY', 'COLOR_PLAYER_WHITE_TEXT');	

INSERT INTO Colors 
		(Type, Red, Green, Blue, Alpha)
VALUES	('COLOR_PLAYER_CETD_BD_PRIMARY', 1, 0, 0, 1), -- Rojo
		('COLOR_PLAYER_CETD_BD_SECONDARY', 0.5, 0.5, 0.5, 1); -- Gris

INSERT INTO Types(Type, Kind) VALUES
('UNIT_TOOTHLESS_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_TOOTHLESS_CETD_BD', 'LOC_UNIT_TOOTHLESS_CETD_BD_NAME', 8, 6, 10, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_TOOTHLESS_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

INSERT INTO Types(Type, Kind) VALUES
('UNIT_STORMFLY_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_STORMFLY_CETD_BD', 'LOC_UNIT_STORMFLY_CETD_BD_NAME', 6, 5, 7, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_STORMFLY_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

INSERT INTO Types(Type, Kind) VALUES
('UNIT_MEATLUG_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_MEATLUG_CETD_BD', 'LOC_UNIT_MEATLUG_CETD_BD_NAME', 4, 3, 5, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_MEATLUG_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

INSERT INTO Types(Type, Kind) VALUES
('UNIT_HOOKFANG_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_HOOKFANG_CETD_BD', 'LOC_UNIT_HOOKFANG_CETD_BD_NAME', 5, 4, 8, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_HOOKFANG_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

INSERT INTO Types(Type, Kind) VALUES
('UNIT_BARFANDBELCH_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_BARFANDBELCH_CETD_BD', 'LOC_UNIT_BARFANDBELCH_CETD_BD_NAME', 6, 5, 7, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_BARFANDBELCH_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');





