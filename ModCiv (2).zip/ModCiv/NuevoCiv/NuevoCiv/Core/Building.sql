INSERT INTO Types (Type, Kind)
VALUES ('BUILDING_DRAGON_ACADEMY', 'KIND_BUILDING');

INSERT INTO Buildings (BuildingType, Name, PrereqDistrict, Cost, Maintenance, Era, PrereqTech, PrereqCivic, Description)
VALUES ('BUILDING_DRAGON_ACADEMY', 'LOC_BUILDING_CETD_BD_DRAGON_ACADEMY_NAME', 'DISTRICT_CAMPUS', 200, 1, 'ERA_ANCIENT', NULL, NULL, 'A unique building for the How to Train Your Dragon civilization.');

INSERT INTO Building_YieldChanges (BuildingType, YieldType, YieldChange)
VALUES ('BUILDING_DRAGON_ACADEMY', 'YIELD_PRODUCTION', 1);

INSERT INTO Building_GreatPersonPoints (BuildingType, GreatPersonClassType, PointsPerTurn)
VALUES ('BUILDING_DRAGON_ACADEMY', 'GREAT_PERSON_CLASS_GENERAL', 1);

INSERT INTO Modifiers (ModifierId, ModifierType)
VALUES ('CETD_BD_DRAGON_ACADEMY_BARB_DAMAGE', 'MODIFIER_PLAYER_UNITS_ADJUST_BARBARIAN_COMBAT');

INSERT INTO ModifierArguments (ModifierId, Name, Value)
VALUES ('CETD_BD_DRAGON_ACADEMY_BARB_DAMAGE', 'Amount', 1);

INSERT INTO BuildingModifiers (BuildingType, ModifierId)
VALUES ('BUILDING_CETD_BD_DRAGON_ACADEMY', 'CETD_BD_DRAGON_ACADEMY_BARB_DAMAGE');
