--LIDER (NOMBRE)
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_LEADER_HICCUP_BD', 'Hipo');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_LEADER_HICCUP_BD', 'Hiccup');		

INSERT INTO LocalizedText
		(Language, Tag, Text)LOC_PEDIA_CIVILIZATIONS_PAGE_CETD_BD_CHAPTER_HISTORY_PARA
VALUES	('es_ES', 'LOC_LEADER_HICCUP_BD_NAME', 'Hipo');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_LEADER_HICCUP_BD_NAME', 'Hiccup');

--LIDER (LOADING INFO)
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_LOADING_INFO_LEADER_HICCUP_BD', 'Confia en tu instinto, Hipo, y forjaros un futuro brillante para Berk. Tu valentia y creatividad inspiraron a dragones y vikingos por igual. Manten la paz y la cooperacion en tu corazon, y lidera con compasion y sabiduria. Con Chimuelo a tu lado, surcaras los cielos y protegeras a tu pueblo. Recuerda, la verdadera fuerza reside en la union y el entendimiento.');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_LOADING_INFO_LEADER_HICCUP_BD', 'Trust your instincts, Hiccup, and you will forge a bright future for Berk. Your bravery and creativity will inspire both dragons and Vikings alike. Keep peace and cooperation in your heart, and lead with compassion and wisdom. With Toothless by your side, you will soar through the skies and protect your people. Remember, true strength lies in unity and understanding.');

--LIDER (CIVILOPEDIA)
	--Titulo/Subtitulo
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_TITLE', 'Hipo');
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_TITLE', 'Hiccup');
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_SUBTITLE', 'Hipo Horrendo Abadejo III');
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_SUBTITLE', 'Hiccup Horrendous Haddock III');
	--Quote
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_QUOTE', 'La confianza de un dragon se gana, no se da');
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_QUOTE', 'A dragons trust is earned, not given');
	--Contexto Historico
		--Espa?ol
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_1', 'Hipo Horrendo Abadejo III fue el jefe supremo de los vikingos de Berk, una isla remota en el Archipi?lago B?rbaro. Nacido en una ?poca donde la enemistad con los dragones era la norma, Hipo revolucion? la relaci?n de su pueblo con estas criaturas. Desde joven, Hipo mostr? una inteligencia y un coraje poco comunes. A pesar de ser hijo del poderoso y tradicionalista Stoick el Vasto, Hipo no encajaba en el molde del vikingo t?pico. Era delgado, ingenioso y prefer?a la raz?n sobre la fuerza bruta.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_2', 'El punto de inflexion en su vida ocurri? cuando, durante una cacer?a de dragones, Hipo derrib? a un Furia Nocturna, una de las especies m?s temidas y desconocidas de dragones. En lugar de matarlo, Hipo lo dej? libre y, eventualmente, form? un v?nculo con ?l, nombr?ndolo Chimuelo. Este acto de compasi?n cambi? no solo su vida, sino la de toda su comunidad. Hipo y Chimuelo demostraron que dragones y humanos pod?an coexistir y beneficiarse mutuamente, desafiando siglos de prejuicios y hostilidades.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_3', 'A medida que Hipo crecia, asumio mas responsabilidades y lider? a su pueblo hacia una nueva era de cooperaci?n y comprensi?n con los dragones. Bajo su liderazgo, Berk se convirti? en un refugio para dragones, desarrollando una simbiosis ?nica donde ambas especies prosperaban juntas. Hipo promovi? el aprendizaje y la innovaci?n, fomentando una cultura de ingenier?a avanzada y empat?a.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_4', 'Sin embargo, el camino no fue f?cil. Hipo enfrent? numerosos desaf?os, incluyendo la amenaza de cazadores de dragones como Drago Bludvist, quien buscaba esclavizar a los dragones para su propio beneficio. Hipo demostr? ser un l?der astuto y valiente, uniendo a los clanes vikingos y a los dragones en una resistencia formidable. Su capacidad para forjar alianzas y su inquebrantable creencia en la paz y la cooperaci?n fueron cruciales en estas batallas.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_5', 'Hipo tambien tuvo que lidiar con la p?rdida personal. La muerte de su padre, Stoick, a manos de un drag?n controlado por Drago, fue un golpe devastador. No obstante, Hipo se mantuvo firme en sus convicciones y continu? liderando a su pueblo con sabidur?a y compasi?n, honrando el legado de su padre mientras forjaba su propio camino.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_6', 'El amor tambien jugo un papel importante en la vida de Hipo. Astrid Hofferson, una valiente y habilidosa guerrera vikinga, se convirti? en su compa?era leal y eventual esposa. Juntos, no solo fortalecieron los lazos entre los vikingos y los dragones, sino que tambi?n prepararon a la siguiente generaci?n para continuar con su visi?n de un mundo en armon?a.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_7', 'Con el tiempo, Hipo y Chimuelo enfrentaron una decisi?n dif?cil: para proteger a los dragones de la creciente amenaza humana, decidieron llevarlos al Mundo Oculto, un santuario seguro lejos de la civilizaci?n humana. Este sacrificio marc? el fin de una era, pero tambi?n asegur? la supervivencia de los dragones. Aunque separados f?sicamente, Hipo y Chimuelo mantuvieron un v?nculo indestructible, simbolizando la esperanza de un futuro donde humanos y dragones pudieran reunirse nuevamente en paz.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_8', 'Hipo Horrendo Abadejo III dejo un legado imborrable como el l?der que transform? el odio en comprensi?n, y la guerra en paz. Su vida es una prueba de que la verdadera grandeza no reside en la fuerza f?sica, sino en el coraz?n y la mente.');
		--Ingles
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_1', 'Hiccup Horrendous Haddock III was the chief of the Vikings of Berk, a remote island in the Barbaric Archipelago. Born into a time where enmity with dragons was the norm, Hiccup revolutionized his peoples relationship with these creatures. From a young age, Hiccup displayed uncommon intelligence and courage. Despite being the son of the powerful and traditionalist Stoick the Vast, Hiccup did not fit the mold of the typical Viking. He was slender, ingenious, and preferred reason over brute force.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_2', 'The turning point in his life came when, during a dragon hunt, Hiccup shot down a Night Fury, one of the most feared and unknown species of dragons. Instead of killing it, Hiccup set it free and eventually formed a bond with it, naming it Toothless. This act of compassion changed not only his life but that of his entire community. Hiccup and Toothless proved that dragons and humans could coexist and benefit each other, challenging centuries of prejudice and hostility.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_3', 'As Hiccup grew older, he took on more responsibilities and led his people into a new era of cooperation and understanding with dragons. Under his leadership, Berk became a haven for dragons, developing a unique symbiosis where both species thrived together. Hiccup promoted learning and innovation, fostering a culture of advanced engineering and empathy.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_4', 'However, the path was not easy. Hiccup faced numerous challenges, including the threat of dragon hunters like Drago Bludvist, who sought to enslave dragons for their own gain. Hiccup proved to be a cunning and brave leader, uniting Viking clans and dragons in a formidable resistance. His ability to forge alliances and his unwavering belief in peace and cooperation were crucial in these battles.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_5', 'Hiccup also had to deal with personal loss. The death of his father, Stoick, at the hands of a dragon controlled by Drago, was a devastating blow. Nevertheless, Hiccup remained steadfast in his convictions and continued to lead his people with wisdom and compassion, honoring his fathers legacy while forging his own path.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_6', 'Love also played a significant role in Hiccups life. Astrid Hofferson, a brave and skilled Viking warrior, became his loyal companion and eventual wife. Together, they not only strengthened the bonds between Vikings and dragons but also prepared the next generation to carry on their vision of a world in harmony.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_7', 'Eventually, Hiccup and Toothless faced a difficult decision: to protect the dragons from the growing human threat, they decided to take them to the Hidden World, a safe sanctuary far from human civilization. This sacrifice marked the end of an era but also ensured the dragons survival. Although physically separated, Hiccup and Toothless maintained an unbreakable bond, symbolizing the hope for a future where humans and dragons could reunite in peace.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('en_US', 'LOC_PEDIA_LEADERS_PAGE_LEADER_HICCUP_BD_CHAPTER_HISTORY_PARA_8', 'Hiccup Horrendous Haddock III left an indelible legacy as the leader who transformed hatred into understanding, and war into peace. His life is a testament to the fact that true greatness lies not in physical strength but in the heart and mind.');

--CIVILIZACI?N (NOMBRE)
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CIVILIZATION_CETD_BD_NAME' , 'Como entrenar a tu dragon');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_CIVILIZATION_CETD_BD_NAME', 'How to train your dragon');
--CIVILIZACI?N (DESCRIPCI?N)
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CIVILIZATION_CETD_BD_DESCRIPTION', 'Imperio de Como entrenar a tu drag?n');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_CIVILIZATION_CETD_BD_DESCRIPTION', 'How to train your dragon empire');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CIVILIZATION_CETD_BD_DESCRIPTION_TEMP_CIVILIZATION', 'Imperio de C�mo entrenar a tu drag?n');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_CIVILIZATION_CETD_BD_DESCRIPTION_TEMP_CIVILIZATION', 'How to train your dragon empire');

--CIVILIZACI?N (ADJETIVO -POBLACI?N-)
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CIVILIZATION_CETD_BD_ADJECTIVE', 'Habitante de Como entrenar a tu dragon|Habitante de C?mo entrenar a tu drag?n|Habitantes de C?mo entrenar a tu drag?n|Habitantes de C?mo entrenar a tu drag?n');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_CIVILIZATION_CETD_BD_ADJECTIVE', 'Resident of How to train your dragon|Resident of How to train your dragon|Residents of How to train your dragon| Residents of How to train your dragon');

--CIVILIZACION (NOMBRES CIUDADANOS)
--espanol
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MALE_1', 'Bocon');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MALE_2', 'Estoico');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MALE_3', 'Mocoso');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MALE_4', 'Pat�n');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MALE_5', 'Cabeza Dura');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_FEMALE_1', 'Astrid');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_FEMALE_2', 'Valka');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_FEMALE_3', 'Brusca');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_FEMALE_4', 'Ruffnut');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_FEMALE_5', 'Camicazi');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_1', 'Eret');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_2', 'Alvin');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_3', 'Dagur');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_4', 'Viggo');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_5', 'Ryker');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_1', 'Heather');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_2', 'Mala');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_3', 'Atali');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_4', 'Ingrid');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_5', 'Thyra');
--ingles
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MALE_1', 'Gobber');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MALE_2', 'Stoick');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MALE_3', 'Snotlout');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MALE_4', 'Tuffnut');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MALE_5', 'Hardhead');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_FEMALE_1', 'Astrid');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_FEMALE_2', 'Valka');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_FEMALE_3', 'Ruffnut');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_FEMALE_4', 'Ruffnut');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_FEMALE_5', 'Camicazi');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_1', 'Eret');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_2', 'Alvin');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_3', 'Dagur');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_4', 'Viggo');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_MALE_5', 'Ryker');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_1', 'Heather');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_2', 'Mala');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_3', 'Atali');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_4', 'Ingrid');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITIZEN_CETD_BD_MODERN_FEMALE_5', 'Thyra');

--Traits
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_TRAIT_LEADER_HICCUP_BD_LTRAIT_NAME', 'Leader Trait');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_TRAIT_LEADER_HICCUP_BD_LTRAIT_NAME', 'Rasgo de lider');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('es_ES', 'LOC_TRAIT_LEADER_HICCUP_BD_LTRAIT_DESCRIPTION', 'Bonus contra barbaros');
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_TRAIT_LEADER_HICCUP_BD_LTRAIT_DESCRIPTION', 'Bonus against barbarian');

--CIVILIZACI?N (CITY NAMES)
--Espa?ol
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_1', 'Mema');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_2', 'Vanaheim');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_3', 'Mundo Oculto');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_4', 'Berserker');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_5', 'Ciudad de los Dragones');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_6', 'Ciudad de las Doncedas Aladas');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_7', 'Ciudad de los Marginados');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_8', 'Dramill?n');		
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_9', 'Ciudad Melod?a');		
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_10', 'Ciudad Nocturna');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_11', 'Valhala');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_12', 'Ciudad de los Exiliados');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_13', 'Ciudad de los Sin diente');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_14', 'Ciudad calavera');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_15', 'Ciudad de los Susurros');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_16', 'Ciudad del Roc?o Dorado');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_17', 'Frostvale');
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_18', 'Mistmoor');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_19', 'Galileo');	
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('es_ES', 'LOC_CITY_NAME_20', 'Aetheris');		

--Ingl?s
INSERT INTO LocalizedText
		(Language, Tag, Text)
VALUES	('en_US', 'LOC_CITY_NAME_1', 'Berk');	
INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_2', 'Vanaheim');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_3', 'Hidden World');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_4', 'Berserker');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_5', 'City of Dragons');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_6', 'City of Winged Maidens');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_7', 'City of Outcasts');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_8', 'Dramillion');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_9', 'Melody City');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_10', 'Night City');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_11', 'Valhalla');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_12', 'City of Exiles');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_13', 'City of Toothless');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_14', 'Skull City');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_15', 'City of Whispers');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_16', 'Golden Dew City');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_17', 'Frostvale');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_18', 'Mistmoor');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_19', 'Galileo');

INSERT INTO LocalizedText
        (Language, Tag, Text)
VALUES  ('en_US', 'LOC_CITY_NAME_20', 'Aetheris');			

--CIVILIZACI?N (CIVILOPEDIA)
	--Location/Size/Population/Capital
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_CIVINFO_CETD_BD_LOCATION', 'Archipielago en algun lugar fant?stico');	
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES  ('en_US', 'LOC_CIVINFO_CETD_BD_LOCATION', 'Archipelago in some fantastic place');

	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_CIVINFO_CETD_BD_SIZE', '8.5 millones de kilometros cuadrados');	
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES  ('en_US', 'LOC_CIVINFO_CETD_BD_SIZE', '8.5 million square kilometers');

	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_CIVINFO_CETD_BD_POPULATION', 'Aprox. 193 millones');	
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES  ('en_US', 'LOC_CIVINFO_CETD_BD_POPULATION', 'Approx. 193 million');

	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES	('es_ES', 'LOC_CIVINFO_CETD_BD_CAPITAL', 'Mema');
	INSERT INTO LocalizedText
			(Language, Tag, Text)
	VALUES  ('en_US', 'LOC_CIVINFO_CETD_BD_CAPITAL', 'Berk');

	--Contexto Historico
		--Espa?ol
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_1', 'Este archipi?lago situado en un reino fant?stico y legendario, es un lugar de asombrosa belleza natural y diversidad geogr?fica. Desde imponentes monta?as nevadas hasta exuberantes bosques y vastos oc?anos, Berk ofrece una variedad de paisajes que han moldeado la vida y la cultura de sus habitantes. En tiempos antiguos, estas islas estaban cubiertas de densos bosques y escarpados acantilados, proporcionando refugio tanto para los dragones como para los vikingos que all? habitaban. La riqueza de su entorno natural fue fundamental para la supervivencia y prosperidad de sus primeras tribus.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_2', 'Los primeros asentamientos vikingos se establecieron en las costas protegidas y en las f?rtiles llanuras interiores. La tierra, aunque dura y a menudo inh?spita, ofrec?a recursos abundantes como pesca, caza y tierras cultivables. A lo largo de los siglos, los vikingos desarrollaron una profunda conexi?n con su entorno, aprendiendo a navegar los traicioneros mares y a cosechar los frutos de la tierra con respeto y sabidur?a. Los cambios estacionales tra?an desaf?os ?nicos, como los inviernos severos y las tormentas oce?nicas, que forjaron el car?cter resistente y adaptable de los habitantes de esta civilizaci?n.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_3', 'La presencia de dragones a?adi? una capa de complejidad a la vida en el archipi?lago. Las islas eran hogar de una diversidad de especies de dragones, cada una adaptada a diferentes nichos ecol?gicos. Estos seres majestuosos ocupaban desde las altas monta?as hasta las profundas cavernas subterr?neas y las vastas extensiones del mar. Inicialmente, la relaci?n entre vikingos y dragones estaba marcada por la confrontaci?n, ya que ambos compet?an por los mismos recursos. Sin embargo, la tierra misma, con sus misteriosos bosques y ocultos valles, jug? un papel crucial en la evoluci?n de su coexistencia.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_4', 'La era de la paz y la armon?a comenz? con el descubrimiento del Valle de los Dragones, un santuario escondido en el coraz?n del archipi?lago. Este lugar, protegido por barreras naturales y m?gico en su esencia, se convirti? en el epicentro del cambio. Aqu?, los vikingos aprendieron a vivir en sinton?a con los dragones, respetando su territorio y sus costumbres. Las maravillas naturales del Valle, con sus cascadas cristalinas y frondosos claros, sirvieron como un recordatorio constante de la importancia de la conservaci?n y el equilibrio ecol?gico.');
		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES	('es_ES', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_5', 'Hoy en d?a, esta civilizaci?n sigue siendo un testimonio de la coexistencia armoniosa entre humanos y dragones, en un entorno natural rico y variado. Las islas contin?an siendo exploradas, revelando nuevos secretos y maravillas con cada generaci?n. La tierra de Berk, con sus paisajes imponentes y su historia legendaria, sigue inspirando a sus habitantes a vivir en armon?a con la naturaleza y a proteger el legado de paz y cooperaci?n que se ha construido sobre sus rocosos y verdes terrenos.');
		--Ingl?s
		INSERT INTO LocalizedText
        (Language, Tag, Text)
		VALUES  ('en_US', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_1', 'This archipelago, located in a fantastic and legendary realm, is a place of astounding natural beauty and geographical diversity. From towering snowy mountains to lush forests and vast oceans, Berk offers a variety of landscapes that have shaped the life and culture of its inhabitants. In ancient times, these islands were covered with dense forests and rugged cliffs, providing shelter for both dragons and the Vikings who inhabited them. The richness of its natural environment was crucial for the survival and prosperity of its early tribes.');

		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES  ('en_US', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_2', 'The first Viking settlements were established on the protected coasts and in the fertile inland plains. The land, though harsh and often inhospitable, offered abundant resources such as fishing, hunting, and arable land. Over the centuries, the Vikings developed a deep connection with their environment, learning to navigate the treacherous seas and to harvest the fruits of the land with respect and wisdom. The seasonal changes brought unique challenges, such as severe winters and ocean storms, which forged the resilient and adaptable character of the inhabitants of this civilization.');

		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES  ('en_US', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_3', 'The presence of dragons added a layer of complexity to life in the archipelago. The islands were home to a diversity of dragon species, each adapted to different ecological niches. These majestic beings occupied everything from high mountains to deep underground caves and the vast expanses of the sea. Initially, the relationship between Vikings and dragons was marked by confrontation, as both competed for the same resources. However, the land itself, with its mysterious forests and hidden valleys, played a crucial role in the evolution of their coexistence.');

		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES  ('en_US', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_4', 'The era of peace and harmony began with the discovery of the Dragon Valley, a hidden sanctuary in the heart of the archipelago. This place, protected by natural barriers and magical in its essence, became the epicenter of change. Here, the Vikings learned to live in harmony with the dragons, respecting their territory and customs. The natural wonders of the Valley, with its crystal-clear waterfalls and lush clearings, served as a constant reminder of the importance of conservation and ecological balance.');

		INSERT INTO LocalizedText
				(Language, Tag, Text)
		VALUES  ('en_US', 'LOC_PEDIA_CIVILIZATIONS_PAGE_CIVILIZATION_CETD_BD_CHAPTER_HISTORY_PARA_5', 'Today, this civilization remains a testament to the harmonious coexistence between humans and dragons in a rich and varied natural environment. The islands continue to be explored, revealing new secrets and wonders with each generation. The land of Berk, with its imposing landscapes and legendary history, continues to inspire its inhabitants to live in harmony with nature and to protect the legacy of peace and cooperation that has been built upon its rocky and green terrains.');

--BUILDING
INSERT INTO LocalizedText (Language, Tag, Text) VALUES
('es_ES', 'LOC_BUILDING_CETD_BD_DRAGON_ACADEMY_NAME', 'Academia de Dragones'),
('en_US', 'LOC_BUILDING_CETD_BD_DRAGON_ACADEMY_NAME', 'Dragon Academy'),
("es_ES","LOC_BUILDING_CETD_BD_DRAGON_ACADEMY_DESCRIPTION","Esta Academia de Dragones es el edificio �nico."),
("en_US","LOC_BUILDING_CETD_BD_DRAGON_ACADEMY_DESCRIPTION","This Dragon's Academy is the unique building.");

--UNITS
INSERT INTO LocalizedText(Language, Tag, Text) VALUES
('en_US', 'LOC_UNIT_BARFANDBELCH_CETD_BD_NAME', 'Barf and Belch'),
('en_US', 'LOC_UNIT_BARFANDBELCH_CETD_BD_DESCRIPTION', 'Two-headed dragon that expels flammable gas from one head and ignites it with the other.'),
('es_ES', 'LOC_UNIT_BARFANDBELCH_CETD_BD_NAME', 'V�mito y Eructo'),
('es_ES', 'LOC_UNIT_BARFANDBELCH_CETD_BD_DESCRIPTION', 'Drag�n de dos cabezas que expulsa gas inflamable por una cabeza y lo enciende con la otra.');

INSERT INTO LocalizedText(Language, Tag, Text) VALUES
('en_US', 'LOC_UNIT_HOOKFANG_CETD_BD_NAME', 'Hookfang'),
('en_US', 'LOC_UNIT_HOOKFANG_CETD_BD_DESCRIPTION', 'Large, red and with the ability to envelop its body in flames.'),
('es_ES', 'LOC_UNIT_HOOKFANG_CETD_BD_NAME', 'Garfios'),
('es_ES', 'LOC_UNIT_HOOKFANG_CETD_BD_DESCRIPTION', 'Grande, rojo y con capacidad de envolver su cuerpo en llamas.');

INSERT INTO LocalizedText(Language, Tag, Text) VALUES
('en_US', 'LOC_UNIT_MEATLUG_CETD_BD_NAME', 'Meatlug'),
('en_US', 'LOC_UNIT_MEATLUG_CETD_BD_DESCRIPTION', 'Robust and rocky Gronckle, known for its resistance.'),
('es_ES', 'LOC_UNIT_MEATLUG_CETD_BD_NAME', 'Barrilete'),
('es_ES', 'LOC_UNIT_MEATLUG_CETD_BD_DESCRIPTION', 'Gronckle robusto y rocoso, conocido por su resistencia.');

INSERT INTO LocalizedText(Language, Tag, Text) VALUES
('en_US', 'LOC_UNIT_STORMFLY_CETD_BD_NAME', 'Stormfly'),
('en_US', 'LOC_UNIT_STORMFLY_CETD_BD_DESCRIPTION', 'Deadly Nadder: Agile and colorful dragon, with poisonous spikes on its tail and an explosive fire breath, ideal for precise attacks and ranged combat.'),
('es_ES', 'LOC_UNIT_STORMFLY_CETD_BD_NAME', 'Tormenta'),
('es_ES', 'LOC_UNIT_STORMFLY_CETD_BD_DESCRIPTION', 'Nadder Mort�fero: Drag�n �gil y colorido, con p�as venenosas en su cola y un aliento de fuego explosivo, ideal para ataques precisos y combate a distancia.');

INSERT INTO LocalizedText(Language, Tag, Text) VALUES
('en_US', 'LOC_UNIT_TOOTHLESS_CETD_BD_NAME', 'Toothless'),
('en_US', 'LOC_UNIT_TOOTHLESS_CETD_BD_DESCRIPTION', 'A rare and powerful Night Fury with extreme speed, deadly plasma shots and night camouflage ability, ideal for quick attacks and ambushes.'),
('es_ES', 'LOC_UNIT_TOOTHLESS_CETD_BD_NAME', 'Desdentao'),
('es_ES', 'LOC_UNIT_TOOTHLESS_CETD_BD_DESCRIPTION', 'Un Furia Nocturna, raro y poderoso, con velocidad extrema, disparos de plasma mortales y capacidad de camuflaje nocturno, ideal para ataques r�pidos y emboscadas.');

