--Desdentado
INSERT INTO Types(Type, Kind) VALUES
('UNIT_TOOTHLESS_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_TOOTHLESS_CETD_BD', 'LOC_UNIT_TOOTHLESS_CETD_BD_NAME', 8, 6, 10, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_TOOTHLESS_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

--Tormenta
INSERT INTO Types(Type, Kind) VALUES
('UNIT_STORMFLY_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_STORMFLY_CETD_BD', 'LOC_UNIT_STORMFLY_CETD_BD_NAME', 6, 5, 7, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_STORMFLY_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

--Barrilete
INSERT INTO Types(Type, Kind) VALUES
('UNIT_MEATLUG_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_MEATLUG_CETD_BD', 'LOC_UNIT_MEATLUG_CETD_BD_NAME', 4, 3, 5, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_MEATLUG_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

--Garfios
INSERT INTO Types(Type, Kind) VALUES
('UNIT_HOOKFANG_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_HOOKFANG_CETD_BD', 'LOC_UNIT_HOOKFANG_CETD_BD_NAME', 5, 4, 8, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_HOOKFANG_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

--VomitoEructo

INSERT INTO Types(Type, Kind) VALUES
('UNIT_BARFANDBELCH_CETD_BD', 'KIND_UNIT');

INSERT INTO Units(UnitType, Name, BaseSightRange, BaseMoves, Combat, Domain, FormationClass, Cost, Description, PromotionClass, PurchaseYield, ZoneOfControl, AdvisorType) VALUES
('UNIT_BARFANDBELCH_CETD_BD', 'LOC_UNIT_BARFANDBELCH_CETD_BD_NAME', 6, 5, 7, 'DOMAIN_AIR', 'FORMATION_CLASS_AIR_COMBAT', 30, 'LOC_UNIT_BARFANDBELCH_CETD_BD_NEW_DESCRIPTION', 'PROMOTION_CLASS_AIR', 'YIELD_FAITH', 2, 'ADVISOR_AIR');

INSERT INTO CivilizationUnits(CivilizationType, UnitType) VALUES
('CIVILIZATION_CETD_BD', 'UNIT_TOOTHLESS_CETD_BD');
INSERT INTO CivilizationUnits(CivilizationType, UnitType) VALUES
('CIVILIZATION_CETD_BD', 'UNIT_STORMFLY_CETD_BD');
INSERT INTO CivilizationUnits(CivilizationType, UnitType) VALUES
('CIVILIZATION_CETD_BD', 'UNIT_MEATLUG_CETD_BD');
INSERT INTO CivilizationUnits(CivilizationType, UnitType) VALUES
('CIVILIZATION_CETD_BD', 'UNIT_HOOKFANG_CETD_BD');
INSERT INTO CivilizationUnits(CivilizationType, UnitType) VALUES
('CIVILIZATION_CETD_BD', 'UNIT_BARFANDBELCH_CETD_BD');