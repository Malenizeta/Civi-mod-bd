
INSERT INTO Players	
		(CivilizationType, Portrait, PortraitBackground, LeaderType, LeaderName, LeaderIcon, LeaderAbilityName,	LeaderAbilityDescription, LeaderAbilityIcon, CivilizationName, CivilizationIcon, CivilizationAbilityName, CivilizationAbilityDescription, CivilizationAbilityIcon)
VALUES	('CIVILIZATION_CETD_BD', 
		'LEADER_LEADER_CUSTOM_NEUTRAL.dds', 
		'LEADER_T_ROOSEVELT_BACKGROUND', 
		'LEADER_HICCUP_BD', 
		'LOC_LEADER_HICCUP_BD', 
		'ICON_LEADER_TEMP_LEADER_CUSTOM',	
		'A dragons trust is earned, not given', 
		'Trust your instincts, Hiccup, and you will forge a bright future for Berk. Your bravery and creativity will inspire both dragons and Vikings alike. Keep peace and cooperation in your heart, and lead with compassion and wisdom. With Toothless by your side, you will soar through the skies and protect your people. Remember, true strength lies in unity and understanding. The first Viking settlements were established on the protected coasts and in the fertile inland plains. The land, though harsh and often inhospitable, offered abundant resources such as fishing, hunting, and arable land. Over the centuries, the Vikings developed a deep connection with their environment, learning to navigate the treacherous seas and to harvest the fruits of the land with respect and wisdom. The seasonal changes brought unique challenges, such as severe winters and ocean storms, which forged the resilient and adaptable character of the inhabitants of this civilization.', 
		'ICON_LEADER_TEMP_LEADER_CUSTOM', 
		'Mema Island', 
		'ICON_CIVILIZATION_CETD_BD', 
		'Dragon Academy', 
		'Previous dragon slaying academy. Now training dragon riders.', 
		'ICON_CIVILIZATION_CETD_BD');


INSERT INTO PlayerItems	
		(CivilizationType, LeaderType, Type, Icon, Name, Description, SortIndex)
VALUES	('CIVILIZATION_CETD_BD', 'LEADER_HICCUP_BD', 'BUILDING_DRAGON_ACADEMY',	'ICON_BUILDING_DRAGON_ACADEMY',	'LOC_BUILDING_DRAGON_ACADEMY_NAME',	'LOC_BUILDING_DRAGON_ACADEMY_DESCRIPTION',	30),
		('CIVILIZATION_CETD_BD', 'LEADER_HICCUP_BD', 'UNIT_TOOTHLESS_CETD_BD', 'ICON_UNIT_TEMP_CUSTOM_I', 'LOC_UNIT_TOOTHLESS_CETD_BD_NAME', 'LOC_UNIT_TOOTHLESS_CETD_BD_DESCRIPTION', 20),
		('CIVILIZATION_CETD_BD', 'LEADER_HICCUP_BD', 'UNIT_STORMFLY_CETD_BD',	'ICON_UNIT_TEMP_CUSTOM_II', 'LOC_UNIT_STORMFLY_CETD_BD_NAME', 'LOC_UNIT_STORMFLY_CETD_BD_DESCRIPTION',�10);







